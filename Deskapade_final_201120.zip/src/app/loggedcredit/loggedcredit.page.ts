import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loggedcredit',
  templateUrl: './loggedcredit.page.html',
  styleUrls: ['./loggedcredit.page.scss'],
})
export class LoggedcreditPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
