import { Component, OnInit } from '@angular/core';
import { NavController, } from '@ionic/angular';
import { Router, ActivatedRoute } from '@angular/router';
import { ModalController } from '@ionic/angular';
import { ReviewPage } from '../review/review.page'

@Component({
  selector: 'app-bookingconfirm',
  templateUrl: './bookingconfirm.page.html',
  styleUrls: ['./bookingconfirm.page.scss'],
})
export class BookingconfirmPage implements OnInit {
  bookingData;
  constructor(private navController: NavController,
    public route: ActivatedRoute,
    public modalController: ModalController) {
    this.route.queryParams.subscribe(params => {
      this.bookingData = JSON.parse(params["bookingData"]);
    });
  }

  ngOnInit() {
    this.presentModal()
  }

  home() {
    this.navController.navigateRoot(`/tabs/home`);

  }

  review() {
    this.navController.navigateRoot(`/review`);

  }

  credit() {
    this.navController.navigateRoot(`/tabs/credit`);

  }

  async presentModal() {
    const modal = await this.modalController.create({
      component: ReviewPage,
      cssClass: 'newmodel',
      showBackdrop: true,
      componentProps: {
        booking_id: this.bookingData.id
      }
    });
    return await modal.present().then(() => {
      modal.onDidDismiss().then(() => {
        console.log('nothing');
      })
    })

  }
  close() {
    this.navController.navigateRoot('/tabs/home')
  }

}
