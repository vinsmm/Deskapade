import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute, NavigationExtras } from '@angular/router';
import { NavController, LoadingController, ModalController, ToastController } from '@ionic/angular';
import { CalendarComponentOptions, CalendarModalOptions, CalendarModal } from 'ion2-calendar';

@Component({
  selector: 'app-bookagain',
  templateUrl: './bookagain.page.html',
  styleUrls: ['./bookagain.page.scss'],
})
export class BookagainPage implements OnInit {
  searchForm: FormGroup;
  dateRange: { from: string; to: string; };
  dateMulti: string[];
  date
  type: 'string';
  showToggleButtons
  time;
  myCreditAmt; buyCredit;
  credits;
  durationArr = []

  eventSource: any;
  month: any;
  year: any;
  str3;
  vendorData;
  hours;
  persons = '';
  valildDurationFlag = false;
  notes = ""; bookingtime;
  constructor(public formBuilder: FormBuilder,
    private navController: NavController,
    private router: Router,
    private route: ActivatedRoute,
    public httpClient: HttpClient,
    public toast: ToastController,
    private loadingController: LoadingController,
    public modalCtrl: ModalController) {
    this.route.queryParams.subscribe(params => {
      this.vendorData = JSON.parse(params["vendorData"])
      console.log(this.vendorData)
    });
    this.searchForm = this.formBuilder.group({
      date: '',

    });

  }
  ngOnInit() {
    // this.getVendorDetailById()
    this.str3 = ""//localStorage.getItem('entDate');
    this.time = "" //localStorage.getItem('stime');
    this.hours = this.vendorData.booking_hours
    this.persons = this.vendorData.total_persons//localStorage.getItem('persons')
    this.durationArr = [
      { 'hour': "1", 'hourText': '1hour' },
      { 'hour': "2", 'hourText': '2hours' },
      { 'hour': "3", 'hourText': '3hours' },
      { 'hour': "4", 'hourText': '4hours' },
      { 'hour': "5", 'hourText': '5hours' },
      { 'hour': "6", 'hourText': '6hours' },
      { 'hour': "7", 'hourText': '7hours' },
      { 'hour': "8", 'hourText': '8hours' },
      { 'hour': "9", 'hourText': '9hours' },
      { 'hour': "10", 'hourText': '10hours' },
    ]
    this.calculateCredits()
  }
  calculateCredits() {
    var entered_hours = this.vendorData.booking_hours//parseInt(localStorage.getItem("min_hours"));
    var entered_persons = this.vendorData.total_persons//parseInt(localStorage.getItem('persons'));

    var hoursParam = Math.ceil(entered_hours / parseInt(this.vendorData.booking_hours));
    var personParam = Math.ceil(entered_persons / parseInt(this.vendorData.max_persons))

    if (hoursParam <= personParam) {
      this.credits = parseInt(this.vendorData.fix_price) * personParam
    } else {
      this.credits = parseInt(this.vendorData.fix_price) * hoursParam
    }

  }
  async openCalendar() {
    const options: CalendarModalOptions =
    {
      title: '',
      color: 'primary',
      cssClass: 'calendarcss',
    };
    let myCalendar = await this.modalCtrl.create({
      component: CalendarModal,
      componentProps: { options }
    });
    myCalendar.present();
    myCalendar.onDidDismiss().then((result) => {
      if (result.data != undefined) {
        var splitedDate = result.data.string.split("-")
        this.date = splitedDate[2]//result.data.date
        this.month = splitedDate[1]//result.data.months
        this.year = splitedDate[0]//result.data.years
        this.str3 = this.date + '-' + this.month + '-' + this.year;
      }

    });
  }

  //Check Booking Availability
  async checkAvailable() {
    if (this.str3.length && this.time.length) {
      console.log(this.str3, " ", this.time.substring(11, 16))
      let data = new FormData();
      data.append('security_key', '3067a0df625299b7128407c74a9e2c63a8b25c8c');
      data.append('booking_id', this.vendorData.id);
      data.append('booking_date', this.str3)
      data.append('booking_time', this.time.substring(11, 16))
      data.append('type_id', this.vendorData.booking_type)
      data.append('vendor_id', this.vendorData.vendor_id);
      data.append('booking_hours', this.vendorData.booking_hours)
      var apiUrl = "http://101.53.143.7/~appempire/deskapade/apis/api/home/"
      const loading = await this.loadingController.create({
        cssClass: 'my-custom-class',
        message: 'Please wait...',

      });
      await loading.present().then(() => {
        this.httpClient.post(apiUrl + 'checkBookingAvailable', data)
          .subscribe((res: any) => {
            console.log(res);
            var sTime = this.time.substring(11, 16); var eTime = parseInt(this.time.substring(11)) + parseInt(this.vendorData.booking_hours);
            if (eTime > 23) {
              this.showToast('Time Exceeding ')
              this.valildDurationFlag = false;
              this.bookingtime = ""
            } else {
              this.bookingtime = sTime + "-" + eTime + ":" + this.time.substring(14, 16)
              console.log(this.bookingtime);
              this.valildDurationFlag = true;
            }


            loading.dismiss()
          }, error => {
            loading.dismiss()
          });

      })
    }
  }

  //proceed to book the venue from rebooking 
  async login() {
    if (this.valildDurationFlag == true) {
      localStorage.setItem('notes', this.notes)
      var loggedin = localStorage.getItem('loggedIn')
      localStorage.setItem('creditAmt', this.credits)
      console.log(loggedin);
      if (loggedin == "true") {
        let data = new FormData();
        data.append('security_key', '61ea8cb8b2d57930b805104c8a31be6b35cfa4f2');
        data.append('user_id', localStorage.getItem('user_id'));
        var apiUrl = "http://101.53.143.7/~appempire/deskapade/apis/api/payments/"
        const loading = await this.loadingController.create({
          cssClass: 'my-custom-class',
          message: 'Please wait...',

        });
        await loading.present().then(() => {
          this.httpClient.post(apiUrl + 'creditHistory', data)
            .subscribe((res: any) => {
              loading.dismiss()
              if (res.status == false) {
                this.myCreditAmt = 0
              } else { 
                this.myCreditAmt = parseInt(res.data[0].total_credits)             
              }
              this.buyCredit = parseInt(localStorage.getItem('creditAmt'))
              if (this.myCreditAmt >= this.buyCredit) {
                var newbuyCredit = this.myCreditAmt - this.buyCredit;
                this.directPurchase(newbuyCredit)
              } else {
                let navObj = {
                  'fromPage': 'bookagain', 'amount': this.credits, 'type_id': this.vendorData.booking_type,
                  'user_id': localStorage.getItem('user_id'), 'vendor_id': this.vendorData.vendor_id,
                  'booking_date': this.str3, 'booking_time': this.time.substring(11, 16), 'booking_hours': this.hours,
                  'total_persons': this.persons, 'total_amt': this.credits, 'addition_notes': localStorage.getItem('notes'),
                  'credit_type': "debit"
                }
                let navigationExtras: NavigationExtras = {
                  queryParams: {
                    pageData: JSON.stringify(navObj)
                  }
                };
                this.navController.navigateForward(`/tabs/upcomingbooking/flowcredit`, navigationExtras);
              }
              
            }, error => {
              loading.dismiss()
            });

        })

      } else {
        // localStorage.setItem('logintype', 'menu')
        // this.navController.navigateForward(`/tabs/home/list/amenity/detailtwo/flowlogin`);
      }
    } else {
      this.showToast('Please select valid date and time')
    }
  }

  async directPurchase(newbuyCredit) {
    let data = new FormData();

    data.append('security_key', 'b4e123dee8c4be95847b2f870c33c423d3653866');
    data.append('amount', this.credits);
    data.append('type_id', this.vendorData.booking_type)
    data.append('user_id', localStorage.getItem('user_id'))
    data.append('vendor_id', this.vendorData.vendor_id)
    data.append('booking_date', this.str3)
    data.append('booking_time', this.time.substring(11, 16))
    data.append('booking_hours', this.hours)
    data.append('total_persons', this.persons)
    data.append('total_amt', this.credits)
    data.append('addition_notes', localStorage.getItem('notes'))
    data.append('credit_type', "debit")

    var apiUrl = "http://101.53.143.7/~appempire/deskapade/apis/api/payments/"
    const loading = await this.loadingController.create({
      cssClass: 'my-custom-class',
      message: 'Please wait...',

    });
    await loading.present().then(() => {
      this.httpClient.post(apiUrl + 'directBooking', data)
        .subscribe((res: any) => {
          console.log(res);
          localStorage.setItem('myCreditAmt', newbuyCredit);
          let navObj = res.data[0]
          let navigationExtras: NavigationExtras = {
            queryParams: {
              bookingData: JSON.stringify(navObj)
            }
          }
          this.navController.navigateForward('/tabs/upcomingbooking/bookingconfirm', navigationExtras)
          loading.dismiss()
        }, error => {
          loading.dismiss()
        });

    })
  }
  async showToast(msg) {
    let toast = await this.toast.create({
      message: msg,
      duration: 3000,
      position: "top"
    })
    toast.present()
  }
}