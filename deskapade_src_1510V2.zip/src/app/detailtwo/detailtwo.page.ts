import { Component, OnInit, NgZone } from '@angular/core';
import { LoadingController, NavController } from '@ionic/angular';
import { Router, NavigationExtras } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-detailtwo',
  templateUrl: './detailtwo.page.html',
  styleUrls: ['./detailtwo.page.scss'],
})
export class DetailtwoPage implements OnInit {
  id
  apiUrl = 'http://101.53.143.7/~appempire/deskapade/apis/api/home/';
  addr1
  addr2
  addr3
  addr4
  addr5
  getId: any;
  vendorDetail: any;
  vendorData: any;
  placeName: any;
  miles: any;
  type: any;
  credits: any;
  notes = ""
  myCreditAmt; buyCredit;
  constructor(public httpClient: HttpClient,
    private navController: NavController,
    private loadingController: LoadingController,
    public zone: NgZone,
    private router: Router, public route: ActivatedRoute) {
    this.route.queryParams.subscribe(params => {
      this.vendorData = JSON.parse(params["vendorData"]);
    });

  }

  ngOnInit() {
    // this.getVendorDetailById()
    this.calculateCredits()
  }

  calculateCredits() {
    var entered_hours = parseInt(localStorage.getItem("min_hours"));
    var entered_persons = parseInt(localStorage.getItem('persons'));
    // var plainCredit=parseInt(this.vendorData.booking_hours)+parseInt(this.vendorData.booking_type)+parseInt(this.vendorData.max_persons);
    // console.log(plainCredit);
    var hoursParam = Math.ceil(entered_hours / parseInt(this.vendorData.booking_hours));
    var personParam = Math.ceil(entered_persons / parseInt(this.vendorData.max_persons))

    if (hoursParam <= personParam) {
      this.credits = parseInt(this.vendorData.fix_price) * personParam
    } else {
      this.credits = parseInt(this.vendorData.fix_price) * hoursParam
    }
    console.log('hoursParam=>', hoursParam, " personParam=>", personParam)
    console.log('entered Hours=>', entered_hours, " Entered persons=>", entered_persons)
    console.log('plaincredit==>', ' calculated Credit=>', this.credits)
  }
  getVendorDetailById() {
    let data = new FormData();
    data.append('security_key', '7ef9c8d85ccee7578ef8c792281914b9e9ab00a3');
    data.append('vendor_id', this.id);

    // let loader = this.loadingCtrl.create({
    //   });  
    // loader.present();
    this.httpClient.post(this.apiUrl + 'serachVendorById', data)
      .subscribe((rdata: any) => {
        this.vendorDetail = rdata.data[0];
        this.placeName = this.vendorDetail.vendor_business;
        this.miles = this.vendorDetail.miles;
        this.type = this.vendorDetail.location_type_name
        this.addr1 = this.vendorDetail.Vendor_addr1
        this.addr2 = this.vendorDetail.Vendor_addr2
        this.addr3 = this.vendorDetail.vendor_town
        this.addr4 = this.vendorDetail.vendor_postcode
        this.addr5 = this.vendorDetail.vendor_country
        this.credits = this.vendorDetail.credit
        console.log(this.vendorDetail);

      }, error => {
      });
  }


  async login() {
    localStorage.setItem('notes', this.notes)
    var loggedin = localStorage.getItem('loggedIn')
    localStorage.setItem('creditAmt', this.credits)
    console.log(loggedin);

    if (loggedin == "true" && localStorage.getItem('user_id') !== null) {
      let data = new FormData();
      data.append('security_key', '61ea8cb8b2d57930b805104c8a31be6b35cfa4f2');
      data.append('user_id', localStorage.getItem('user_id'));
      var apiUrl = "http://101.53.143.7/~appempire/deskapade/apis/api/payments/"
      const loading = await this.loadingController.create({
        cssClass: 'my-custom-class',
        message: 'Please wait...',

      });
      await loading.present().then(() => {
        this.httpClient.post(apiUrl + 'creditHistory', data)
          .subscribe((res: any) => {
             
            // localStorage.setItem('myCreditAmt', );
             if (res.status == false) {
              this.myCreditAmt = 0

            } else { 
              this.myCreditAmt = parseInt(res.data[0].total_credits)             
            }
            this.zone.run(() => {
               
              this.buyCredit = parseInt(localStorage.getItem('creditAmt'))
              if (this.myCreditAmt >= this.buyCredit) {
                var newbuyCredit = this.myCreditAmt - this.buyCredit;
                this.directPurchase(newbuyCredit)
              } else {
                let navObj = { 'fromPage': 'normal' }
                let navigationExtras: NavigationExtras = {
                  queryParams: {
                    pageData: JSON.stringify(navObj)
                  }
                }
                this.navController.navigateForward(`/tabs/home/list/amenity/detailtwo/flowcredit`, navigationExtras);
              }
            })
            loading.dismiss();

          }, error => {
            loading.dismiss()
          });

      })




    } else {
      localStorage.setItem('logintype', 'menu')
      this.navController.navigateForward(`/tabs/home/list/amenity/detailtwo/flowlogin`);
    }
  }
  async directPurchase(newbuyCredit) {
    let data = new FormData();

    data.append('security_key', 'b4e123dee8c4be95847b2f870c33c423d3653866');
    data.append('amount', this.credits);
    data.append('type_id', localStorage.getItem('venue_type'))
    data.append('user_id', localStorage.getItem('user_id'))
    data.append('vendor_id', localStorage.getItem('vendor_id'))
    data.append('booking_date', localStorage.getItem('entDate'))
    data.append('booking_time', localStorage.getItem('stime'))
    data.append('booking_hours', localStorage.getItem('min_hours'))
    data.append('total_persons', localStorage.getItem('persons'))
    data.append('total_amt', this.credits)
    data.append('addition_notes', localStorage.getItem('notes'))
    data.append('credit_type', "debit")
    var apiUrl = "http://101.53.143.7/~appempire/deskapade/apis/api/payments/"
    const loading = await this.loadingController.create({
      cssClass: 'my-custom-class',
      message: 'Please wait...',

    });
    await loading.present().then(() => {
      this.httpClient.post(apiUrl + 'directBooking', data)
        .subscribe((res: any) => {
          console.log(res);
          // localStorage.setItem('myCreditAmt', newbuyCredit);
          let navObj = res.data[0]
          let navigationExtras: NavigationExtras = {
            queryParams: {
              bookingData: JSON.stringify(navObj)
            }
          }
          this.navController.navigateForward('/tabs/home/list/amenity/detailtwo/flowlogin/bookingconfirm', navigationExtras)
          loading.dismiss()
        }, error => {
          loading.dismiss()
        });

    })
  }
}
