import { Component, OnInit, NgZone } from '@angular/core';
import { NavController, LoadingController } from '@ionic/angular';
import { ActivatedRoute, Router, NavigationExtras } from '@angular/router';
import { CalendarComponentOptions } from 'ion2-calendar'
import { CalendarModal, CalendarModalOptions } from 'ion2-calendar';
import { ModalController } from '@ionic/angular';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { getLocalePluralCase } from '@angular/common';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-venudetail',
  templateUrl: './venudetail.page.html',
  styleUrls: ['./venudetail.page.scss'],
})
export class VenudetailPage implements OnInit {
  searchForm: FormGroup;
  dateRange: { from: string; to: string; };
  dateMulti: string[];
  date
  type: 'string';
  showToggleButtons
  time;
  myCreditAmt; buyCredit;
  credits;
  durationArr = []
  optionsMulti: CalendarComponentOptions = {
    pickMode: 'multi'
  };

  optionsRange: CalendarComponentOptions = {
    pickMode: 'range'
  };
  eventSource: any;
  month: any;
  year: any;
  str3;
  vendorData;
  hours;
  persons = '';
  notes = ""
  constructor(public formBuilder: FormBuilder,
    private navController: NavController,
    private router: Router,
    private route: ActivatedRoute,
    public httpClient: HttpClient,
    public zone: NgZone,
    private loadingController: LoadingController,
    public modalCtrl: ModalController) {
    this.route.queryParams.subscribe(params => {
      this.vendorData = JSON.parse(params["vendorData"])
      console.log(this.vendorData)
    });
    this.searchForm = this.formBuilder.group({
      date: '',

    });

  }
  ngOnInit() {
    // this.getVendorDetailById()
    this.str3 = localStorage.getItem('entDate');
    this.time = localStorage.getItem('stime');
    this.persons = localStorage.getItem('persons');
    this.hours=localStorage.getItem('min_hours')
    this.durationArr = [
      { 'hour': "1", 'hourText': '1hour' },
      { 'hour': "2", 'hourText': '2hours' },
      { 'hour': "3", 'hourText': '3hours' },
      { 'hour': "4", 'hourText': '4hours' },
      { 'hour': "5", 'hourText': '5hours' },
      { 'hour': "6", 'hourText': '6hours' },
      { 'hour': "7", 'hourText': '7hours' },
      { 'hour': "8", 'hourText': '8hours' },
      { 'hour': "9", 'hourText': '9hours' },
      { 'hour': "10", 'hourText': '10hours' },
    ]
    this.calculateCredits()
  }
  calculateCredits() {
    var entered_hours = parseInt(localStorage.getItem("min_hours"));
    var entered_persons = parseInt(localStorage.getItem('persons'));
    // var plainCredit=parseInt(this.vendorData.booking_hours)+parseInt(this.vendorData.booking_type)+parseInt(this.vendorData.max_persons);
    // console.log(plainCredit);
    var hoursParam = Math.ceil(entered_hours / parseInt(this.vendorData.booking_hours));
    var personParam = Math.ceil(entered_persons / parseInt(this.vendorData.max_persons))

    if (hoursParam <= personParam) {
      this.credits = parseInt(this.vendorData.fix_price) * personParam
    } else {
      this.credits = parseInt(this.vendorData.fix_price) * hoursParam
    }
    console.log('hoursParam=>', hoursParam, " personParam=>", personParam)
    console.log('entered Hours=>', entered_hours, " Entered persons=>", entered_persons)
    console.log('plaincredit==>', ' calculated Credit=>', this.credits)
  }
  async openCalendar() {

    const options: CalendarModalOptions =
    {
      title: '',
      color: 'primary',
      cssClass: 'calendarcss',
    };
    let myCalendar = await this.modalCtrl.create({
      component: CalendarModal,
      componentProps: { options }
    });

    myCalendar.present();

    myCalendar.onDidDismiss().then((result) => {
      console.log(result)
      var splitedDate = result.data.string.split("-")
      this.date = splitedDate[2]//result.data.date
      this.month = splitedDate[1]//result.data.months
      this.year = splitedDate[0]//result.data.years

      this.str3 = this.date + '-' + this.month + '-' + this.year;
      console.log('date', this.date)
      console.log('month', this.month)
      console.log('year', this.year)
      // this.str3 = this.date + ' - ' + this.month + ' - ' + this.year


      // var str3 = this.date.concat(this.month);


      // console.log(str3);
      // if (result.data && result.data.event) {
      //   let event = result.data.event;
      //   console.log(event)
      //   if (event.allDay) {
      //     let start = event.startTime;
      //     event.startTime = new Date(
      //       Date.UTC(
      //         start.getUTCFullYear(),
      //         start.getUTCMonth(),
      //         start.getUTCDate()
      //       )
      //     );
      //     event.endTime = new Date(
      //       Date.UTC(
      //         start.getUTCFullYear(),
      //         start.getUTCMonth(),
      //         start.getUTCDate() + 1
      //       ) 
      //     );
      //   }

      //   this.eventSource.push(result.data.event);
      //   // this.myCalendar.loadEvents();
      // }
    });

    // myCalendar.onDidDismiss(this.date)
    // console.log(date)
  }
  // login() {
  //   localStorage.setItem('notes',this.notes)
  //   var loggedin = localStorage.getItem('loggedIn')
  //   localStorage.setItem('creditAmt', this.credits) 
  //   console.log(loggedin)
  //   if (loggedin == "true") {
  //     this.navController.navigateForward(`/tabs/home/list/amenity/detailtwo/flowcredit`);
  //   } else {
  //     localStorage.setItem('logintype', 'menu')
  //     this.navController.navigateForward(`/tabs/home/list/amenity/detailtwo/flowlogin`);
  //   }
  //   // this.navController.navigateRoot(`/login`);


  // }
  async login() {
    localStorage.setItem('notes', this.notes)
    var loggedin = localStorage.getItem('loggedIn')
    localStorage.setItem('creditAmt', this.credits)
    console.log(loggedin);

    if (loggedin == "true") {
      let data = new FormData();
      data.append('security_key', '61ea8cb8b2d57930b805104c8a31be6b35cfa4f2');
      data.append('user_id', localStorage.getItem('user_id'));
      var apiUrl = "http://101.53.143.7/~appempire/deskapade/apis/api/payments/"
      const loading = await this.loadingController.create({
        cssClass: 'my-custom-class',
        message: 'Please wait...',

      });
      await loading.present().then(() => {
        this.httpClient.post(apiUrl + 'creditHistory', data)
          .subscribe((res: any) => {
            this.zone.run(() => {
              if (parseInt(res.data[0].total_credits) == undefined) {
                this.myCreditAmt = 0;
              } else {
                this.myCreditAmt = parseInt(res.data[0].total_credits)
              }
              this.buyCredit = parseInt(localStorage.getItem('creditAmt'))
              if (this.myCreditAmt >= this.buyCredit) {
                var newbuyCredit = this.myCreditAmt - this.buyCredit;
                this.directPurchase(newbuyCredit)
              } else {
                let navObj = { 'fromPage': 'normal' }
                let navigationExtras: NavigationExtras = {
                  queryParams: {
                    pageData: JSON.stringify(navObj)
                  }
                }
                this.navController.navigateForward(`/tabs/home/list/amenity/detailtwo/flowcredit`, navigationExtras);
              }
            })
            loading.dismiss()
          }, error => {
            loading.dismiss()
          });

      })

      // this.zone.run(() => {
      //   this.myCreditAmt = parseInt(localStorage.getItem('myCreditAmt'))
      //   this.buyCredit = parseInt(localStorage.getItem('creditAmt'))
      //   if (this.myCreditAmt >= this.buyCredit) {
      //     var newbuyCredit = this.myCreditAmt - this.buyCredit;
      //     console.log("calling direct purchase");
      //      this.directPurchase(newbuyCredit)
      //   } else {
      //     let navObj = { 'fromPage': 'normal' }
      //     let navigationExtras: NavigationExtras = {
      //       queryParams: {
      //         pageData: JSON.stringify(navObj)
      //       }
      //     }
      //     this.navController.navigateForward(`/tabs/home/list/amenity/detailtwo/flowcredit`, navigationExtras);
      //   }
      // })

    } else {
      localStorage.setItem('logintype', 'menu')
      this.navController.navigateForward(`/tabs/home/list/amenity/detailtwo/flowlogin`);
    }
  }
  async directPurchase(newbuyCredit) {
    let data = new FormData();

    data.append('security_key', 'b4e123dee8c4be95847b2f870c33c423d3653866');
    data.append('amount', this.credits);
    data.append('type_id', localStorage.getItem('venue_type'))
    data.append('user_id', localStorage.getItem('user_id'))
    data.append('vendor_id', localStorage.getItem('vendor_id'))
    data.append('booking_date', localStorage.getItem('entDate'))
    data.append('booking_time', localStorage.getItem('stime'))
    data.append('booking_hours', localStorage.getItem('min_hours'))
    data.append('total_persons', localStorage.getItem('persons'))
    data.append('total_amt', this.credits)
    data.append('addition_notes', localStorage.getItem('notes'))
    data.append('credit_type', "debit")
    var apiUrl = "http://101.53.143.7/~appempire/deskapade/apis/api/payments/"
    const loading = await this.loadingController.create({
      cssClass: 'my-custom-class',
      message: 'Please wait...',

    });
    await loading.present().then(() => {
      this.httpClient.post(apiUrl + 'directBooking', data)
        .subscribe((res: any) => {
          console.log(res);
          localStorage.setItem('myCreditAmt', newbuyCredit);
          let navObj = res.data[0]
          let navigationExtras: NavigationExtras = {
            queryParams: {
              bookingData: JSON.stringify(navObj)
            }
          }
          this.navController.navigateForward('/tabs/home/list/amenity/detailtwo/flowlogin/bookingconfirm', navigationExtras)
          loading.dismiss()
        }, error => {
          loading.dismiss()
        });

    })
  }

}
